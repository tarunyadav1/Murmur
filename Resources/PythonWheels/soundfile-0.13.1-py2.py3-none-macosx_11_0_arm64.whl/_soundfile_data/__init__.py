# this file makes _soundfile_data importable, so we can query its path
# when searching for the libsndfile binaries.
pass

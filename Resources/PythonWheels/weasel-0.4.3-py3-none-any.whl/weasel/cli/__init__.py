from .main import app  # isort: skip

from .assets import project_assets
from .clone import project_clone
from .document import project_document
from .dvc import project_update_dvc
from .pull import project_pull
from .push import project_push
from .run import project_run

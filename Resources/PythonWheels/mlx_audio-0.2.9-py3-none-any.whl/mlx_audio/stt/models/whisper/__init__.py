from .whisper import Model

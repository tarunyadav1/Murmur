from .sesame import Model

__all__ = ["Model"]

The contents of `g2pkc` were COPIED from https://github.com/5Hyeons/StyleTTS2/tree/vocos/g2pK/g2pkc
Which in turn was ADAPTED from https://github.com/Kyubyong/g2pK